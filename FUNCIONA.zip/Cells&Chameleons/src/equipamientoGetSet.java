public class equipamientoGetSet {

	private int poder;

	public equipamientoGetSet(int poder) {
		super();
		this.poder = poder;
	}

	public int getPoder() {
		return poder;
	}

	public void setPoder(int poder) {
		this.poder = poder;
	}

	@Override
	public String toString() {
		return "equipamientoGetSet [poder=" + poder + "]";
	}
	
	

	

}
